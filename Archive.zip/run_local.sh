#!/bin/bash
docker run -it --rm -v .:/opt/bitnami/spark/yelp yelp-container
